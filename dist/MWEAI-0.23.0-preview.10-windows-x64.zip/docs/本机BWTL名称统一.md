# 本机界面名称统一为 BWTL

本机版本：`0.21.2-local.bwtl.1`，基于官方 `0.21.2-preview.1`；未发布到远程仓库。

## 调整及原因

按本机使用者要求，将 Creo 功能区选项卡、分组、打开助手的按钮、窗口标题和窗口主标题统一显示为 `BWTL`。原版将“霸威天龙 v21.2”和“Codex Native”等名称分别写在原生窗口源码、菜单资源与消息资源中，不能只修改一个配置实现统一。

仅修改显示字符串和快捷键说明；内部命令 ID、窗口类、建模协议、数据目录、聊天及记忆文件保持原有定义。版本号保留在 VERSION/安装状态中，窗口标题显示纯 BWTL。

## 源码保护与验证

修改前227项冻结检查通过。两个受保护源码文件的差异已逐项检查：`native_ui_create.inc`仅替换两处窗口名称；`user_initialize.inc`仅替换快捷键的显示名称。原文件和原基线另存于本机 `BWTL-local-branding` 目录，仅人工更新这两个文件的冻结哈希，其他225项未变。

新DLL编译后通过PTC官方 `Parametric/bin/protk_unlock.bat` 解锁，解锁后不再修改DLL。7组已有回归和隐藏原生聊天窗口测试通过；真实Creo中核对菜单、分组、按钮、窗口标题和主标题，并检查启动日志返回值及历史恢复。

## 启用

使用本机完整安装包的 `setup/Install-BWTL.ps1 -Silent`，选择原安装根目录及原 `config.pro`。新版本与旧版并存，仍使用原 `data`，安装器备份配置和数据。保存工作并正常重启Creo后生效。入口为顶部 `BWTL`，备用快捷键仍为 `c`、`d`、`x`。

本机安装根目录：`C:\Users\Administrator\AppData\Local\BWTL`。

## 回退

保存工作并退出Creo，在安装管理中选择“回退上一版本”，或运行安装根目录的 `Install-BWTL.ps1 -InstallRoot <安装根目录> -Rollback -Silent`，再重启Creo。回退到 `0.21.2-preview.1` 恢复旧名称，聊天与记忆保留。不要复制旧data覆盖当前聊天。
